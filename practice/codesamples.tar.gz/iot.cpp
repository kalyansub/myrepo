#include <iostream>
using namespace std;

int main(int argc, char* argv[])
{
   int x;
   cout << "Enter input number: ";
   cin >> x;
   cout << "Read :" << x << " from input \n";

   return 0;
}
